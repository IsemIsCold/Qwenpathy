#!/usr/bin/env python3
"""
I1: Build supervised-fine-tuning (SFT) data from train_public.jsonl.

Produces two files:
    data/sft_pairs.jsonl         – {id, prompt, completion} for direct use
    data/sft_llama_factory.json  – Alpaca/ShareGPT format for LLaMA-Factory

Usage:
    python train/build_sft.py \
        --in data/train_public.jsonl \
        --out data/sft_pairs.jsonl \
        --llama-factory data/sft_llama_factory.json \
        [--dev-ratio 0.05] \
        [--max-history-tokens 4096] \
        [--tokenizer Qwen/Qwen2.5-7B-Instruct]

Design decisions:
    - Split by conversation_id (never by prediction point) so all points from
      one conversation land in the same split.
    - Long conversations: drop oldest turns first, always keep the last user
      turn (the one we must reply to).
    - The prompt mirrors the official inference system prompt + history layout.
"""

import argparse
import json
import random
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Official vocabulary (must stay in sync with run_inference.py)
# ---------------------------------------------------------------------------
EMOTIONS = [
    "joy", "gratitude", "relaxed", "care", "pride", "neutral", "surprise",
    "mixed", "sadness", "loneliness", "anxiety", "anger", "fear", "disgust",
    "shame", "helplessness",
]

# ---------------------------------------------------------------------------
# Profile vocabularies — DISCOVERED FROM ACTUAL GOLD DATA (Oct 4).
# The documented README vocabularies were wrong. These match the data.
# ---------------------------------------------------------------------------
PROFILE_SCHEMA = {
    "personality_traits": [
        "sensitive", "conservative", "high_conscientiousness", "assertive",
        "agreeable", "introverted", "emotionally_stable", "casual", "open",
        "extroverted",
    ],
    "interests": [
        "career_development", "pets", "study_exam", "sports_fitness", "games",
        "reading_writing", "art_design", "social", "travel_outdoor", "music",
        "film_animation", "programming_technology",
    ],
    "style": [
        "rational", "direct", "detailed", "brief", "indirect",
        "high_emotional_expression", "colloquial", "formal", "humorous",
        "emoji_user", "low_emotional_expression",
    ],
}

# ---------------------------------------------------------------------------
# System prompt (keep in sync with participant/run_inference.py)
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = f"""你是一个情感陪伴数字人。请根据对话历史，生成合适的回复。

你需要输出以下 JSON 格式：
{{
  "response_text": "你的回复内容",
  "emotion_label": "情绪标签",
  "user_profile": {{
    "personality_traits": [],
    "interests": [],
    "style": []
  }},
  "memory_refs": []
}}

情绪标签必须从以下列表中选择：{', '.join(EMOTIONS)}

personality_traits 可选值：{', '.join(PROFILE_SCHEMA['personality_traits'])}
interests 可选值：{', '.join(PROFILE_SCHEMA['interests'])}
style 可选值：{', '.join(PROFILE_SCHEMA['style'])}

memory_refs 如果没有相关记忆，请输出空列表 []。
"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build SFT training data.")
    parser.add_argument(
        "--in", "-i", dest="input_file",
        default="data/train_public.jsonl",
        help="Input training data",
    )
    parser.add_argument(
        "--out", "-o", dest="output_file",
        default="data/sft_pairs.jsonl",
        help="Output SFT pairs (JSONL)",
    )
    parser.add_argument(
        "--llama-factory", "-lf", dest="llama_factory_file",
        default="data/sft_llama_factory.json",
        help="Output LLaMA-Factory format JSON",
    )
    parser.add_argument(
        "--dev-ratio", type=float, default=0.05,
        help="Fraction of conversations to reserve for dev (default: 0.05)",
    )
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Random seed for split",
    )
    parser.add_argument(
        "--max-history-tokens", type=int, default=4096,
        help="Max tokens for history before truncation (default: 4096)",
    )
    parser.add_argument(
        "--tokenizer", default="Qwen/Qwen2.5-7B-Instruct",
        help="Tokenizer name/path for counting",
    )
    return parser.parse_args()


def load_tokenizer(tokenizer_name: str):
    try:
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained(
            tokenizer_name, trust_remote_code=True, local_files_only=True
        )
        print(f"Loaded tokenizer: {tokenizer_name}")
        return tok
    except Exception as e:
        print(f"WARNING: Could not load tokenizer ({e}). Falling back to char-based heuristic.")
        return None


def count_tokens(text: str, tokenizer) -> int:
    if tokenizer is None:
        # Rough heuristic: 1 token ≈ 1.5 Chinese chars or 4 English chars
        # This is conservative; real tokenizer will give exact counts
        return int(len(text) / 1.5)
    return len(tokenizer.encode(text, add_special_tokens=False))


def render_history(turns: list[dict]) -> str:
    """Render conversation turns as a plain-text history block."""
    lines = []
    for t in turns:
        role = "用户" if t["role"] == "user" else "助手"
        lines.append(f"{role}：{t['content']}")
    return "\n\n".join(lines)


def truncate_history(turns: list[dict], tokenizer, max_tokens: int) -> list[dict]:
    """
    Drop oldest turns until history fits in max_tokens.
    Always keep the last user turn (the target turn).
    """
    if not turns:
        return turns

    # Ensure last turn is user (it should be, but guard anyway)
    # We always keep at least the last turn
    history_text = render_history(turns)
    if count_tokens(history_text, tokenizer) <= max_tokens:
        return turns

    # Drop from the front, but never drop the very last turn
    kept = turns[:]
    while len(kept) > 1:
        kept = kept[1:]  # drop oldest
        history_text = render_history(kept)
        if count_tokens(history_text, tokenizer) <= max_tokens:
            return kept

    return kept


def build_prompt(turns: list[dict]) -> str:
    """
    Build the full prompt for SFT.

    Structure:
        <system prompt>

        对话历史：
        用户：...
        助手：...
        ...

        请生成回复：
    """
    history_block = render_history(turns)
    prompt = f"{SYSTEM_PROMPT}\n\n对话历史：\n{history_block}\n\n请生成回复："
    return prompt


def build_completion(target: dict) -> str:
    """
    Build the completion JSON string.

    Agreed format with Ismail M.: full JSON object with all 4 fields.
    """
    completion_obj = {
        "response_text": target["response_text"],
        "emotion_label": target["emotion_label"],
        "user_profile": target["user_profile"],
        "memory_refs": target.get("memory_refs", []),
    }
    return json.dumps(completion_obj, ensure_ascii=False)


def main() -> None:
    args = parse_args()
    random.seed(args.seed)

    tokenizer = load_tokenizer(args.tokenizer)

    input_path = Path(args.input_file)
    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    # -----------------------------------------------------------------------
    # First pass: load all conversations, collect prediction points
    # -----------------------------------------------------------------------
    conversations = []
    all_points = []  # (conv_idx, point_idx, conversation_id)

    with input_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            conv = json.loads(line)
            conv_idx = len(conversations)
            conversations.append(conv)
            for pidx, _ in enumerate(conv.get("prediction_points", [])):
                all_points.append((conv_idx, pidx, conv["conversation_id"]))

    total_points = len(all_points)
    print(f"Loaded {len(conversations):,} conversations, {total_points:,} prediction points.")

    # -----------------------------------------------------------------------
    # Split by conversation_id
    # -----------------------------------------------------------------------
    unique_conv_ids = list({conv["conversation_id"] for conv in conversations})
    random.shuffle(unique_conv_ids)

    n_dev = max(1, int(len(unique_conv_ids) * args.dev_ratio))
    dev_conv_ids = set(unique_conv_ids[:n_dev])
    train_conv_ids = set(unique_conv_ids[n_dev:])

    print(f"Split: {len(train_conv_ids):,} train convs, {len(dev_conv_ids):,} dev convs")

    # -----------------------------------------------------------------------
    # Second pass: build examples
    # -----------------------------------------------------------------------
    train_examples = []
    dev_examples = []
    truncated_count = 0

    for conv_idx, pidx, conv_id in all_points:
        conv = conversations[conv_idx]
        pp = conv["prediction_points"][pidx]
        target_turn_id = pp["target_user_turn_id"]

        # Extract history up to target turn
        history_turns = [
            t for t in conv["turns"]
            if t["turn_id"] <= target_turn_id
        ]

        # Truncate if too long
        original_len = len(history_turns)
        history_turns = truncate_history(history_turns, tokenizer, args.max_history_tokens)
        if len(history_turns) < original_len:
            truncated_count += 1

        prompt = build_prompt(history_turns)
        completion = build_completion(pp["target"])

        example = {
            "id": f"{conv_id}_t{target_turn_id}",
            "prompt": prompt,
            "completion": completion,
        }

        if conv_id in dev_conv_ids:
            dev_examples.append(example)
        else:
            train_examples.append(example)

    print(f"Built {len(train_examples):,} train examples, {len(dev_examples):,} dev examples.")
    print(f"Truncated histories: {truncated_count} / {total_points} ({truncated_count/total_points*100:.1f}%)")

    # -----------------------------------------------------------------------
    # Write SFT pairs (JSONL)
    # -----------------------------------------------------------------------
    out_path = Path(args.output_file)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with out_path.open("w", encoding="utf-8") as f:
        for ex in train_examples:
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")
        for ex in dev_examples:
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")

    print(f"Wrote SFT pairs: {out_path}")

    # -----------------------------------------------------------------------
    # Write LLaMA-Factory format (JSON)
    # -----------------------------------------------------------------------
    lf_data = []
    for ex in train_examples + dev_examples:
        lf_data.append({
            "instruction": ex["prompt"],
            "input": "",
            "output": ex["completion"],
            "id": ex["id"],
        })

    lf_path = Path(args.llama_factory_file)
    lf_path.parent.mkdir(parents=True, exist_ok=True)
    with lf_path.open("w", encoding="utf-8") as f:
        json.dump(lf_data, f, ensure_ascii=False, indent=2)

    print(f"Wrote LLaMA-Factory format: {lf_path}")

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print("\n" + "=" * 50)
    print("build_sft.py – Done")
    print("=" * 50)
    print(f"Train examples: {len(train_examples):,}")
    print(f"Dev examples:   {len(dev_examples):,}")
    print(f"Total:          {len(train_examples) + len(dev_examples):,}")
    print(f"Truncated:      {truncated_count:,} ({truncated_count/total_points*100:.1f}%)")
    print(f"Files:")
    print(f"  {out_path}")
    print(f"  {lf_path}")
    print("=" * 50)


if __name__ == "__main__":
    main()
