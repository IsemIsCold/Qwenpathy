# Dataset Statistics Report (B6)

> **Generated:** 2026-10-04  
> **Owner:** Zakaria (Dataset)  
> **Files analyzed:** `train_public.jsonl` (8,338 convs) + `val_public.jsonl` (900 convs)  
> **Tokenizer:** Approximate (3.5 chars/token heuristic). Install `transformers` for exact Qwen2.5 counts.

---

## ⚠️ Critical Discovery: Profile Vocabularies

**The documented profile vocabularies do NOT match the actual gold data.** Labels were discovered by scanning the data itself. `validate.py` must **warn, not reject**, on out-of-vocab profile values until organizers confirm the official vocabulary. See Section 5.2 for the corrected list.

---

## 1. Overview

| Metric | Train | Val | Notes |
|--------|-------|-----|-------|
| Conversations | 8,338 | 900 | Val is ~10.8% of train |
| Prediction Points | 18,657 | 2,354 | Avg ~2.2 points per conversation |
| Avg Turns / Conv | 14.1 | 13.0 | Val conversations are slightly shorter |
| Empty Profiles | 6,834 (36.6%) | 875 (37.2%) | Very consistent split |

**Visual:** See `viz_context_thresholds.png` (right panel) for profile coverage pie chart.

---

## 2. Emotion Distribution

### 2.1 Raw Counts

| Emotion | Train Count | Train % | Val Count | Val % | Rare? |
|---------|------------:|--------:|----------:|------:|:-----:|
| anxiety | 6,340 | **34.0%** | 751 | **31.9%** | No |
| relaxed | 2,819 | 15.1% | 409 | 17.4% | No |
| helplessness | 1,575 | 8.4% | 142 | 6.0% | No |
| fear | 1,388 | 7.4% | 124 | 5.3% | No |
| mixed | 945 | 5.1% | 177 | 7.5% | No |
| sadness | 1,085 | 5.8% | 131 | 5.6% | No |
| loneliness | 876 | 4.7% | 115 | 4.9% | No |
| shame | 752 | 4.0% | 118 | 5.0% | No |
| anger | 855 | 4.6% | 115 | 4.9% | No |
| gratitude | 695 | 3.7% | 118 | 5.0% | No |
| neutral | 654 | 3.5% | 53 | 2.3% | Borderline |
| pride | 234 | 1.3% | 40 | 1.7% | **Rare** |
| joy | 171 | 0.9% | 20 | 0.8% | **Rare** |
| disgust | 125 | 0.7% | 21 | 0.9% | **Rare** |
| care | 79 | 0.4% | 11 | 0.5% | **Rare** |
| surprise | 64 | 0.3% | 9 | 0.4% | **Rare** |

### 2.2 Key Findings

- **Top 3 emotions = 56.5% of data:** anxiety (34.0%) + relaxed (15.1%) + helplessness (8.4%)
- **Bottom 5 emotions = 3.3% of data:** surprise, care, disgust, joy, pride combined
- **Train/val distribution is consistent:** No major shift between splits
- **"Always-anxiety" baseline accuracy:** 34.0% (train) / 31.9% (val)

### 2.3 Actionable Insight

> **If the official metric is accuracy (not macro-F1):** The "always-anxiety" baseline gives ~32% accuracy. To win, you need to get the top-5 classes right (anxiety, relaxed, helplessness, fear, mixed = 70.8% of data). Rare-class oversampling may hurt accuracy if it causes misclassification of common classes.
>
> **If macro-F1 is weighted:** Rare emotions (joy, care, surprise) at <1% each will destroy your F1. You MUST oversample or use class-weighted loss.

**Visual:** See `viz_emotion_distribution.png` for side-by-side train/val comparison.

---

## 3. User Profile Statistics

### 3.1 Empty Profile Rate

| Split | Empty | Total | Rate |
|-------|------:|------:|-----:|
| Train | 6,834 | 18,657 | **36.6%** |
| Val | 875 | 2,354 | **37.2%** |

**Implication:** The model must learn to output empty `user_profile` JSON (`{"personality_traits": [], "interests": [], "style": []}`) for ~37% of inputs. If it always predicts labels, it will be wrong 37% of the time on profiles.

### 3.2 Personality Traits (Train)

| Label | Count | % of Points |
|-------|------:|------------:|
| sensitive | 5,165 | 27.7% |
| high_conscientiousness | 2,281 | 12.2% |
| conservative | 1,364 | 7.3% |
| introverted | 717 | 3.8% |
| assertive | 675 | 3.6% |
| agreeable | 361 | 1.9% |
| emotionally_stable | 336 | 1.8% |
| open | 59 | 0.3% |
| extroverted | 37 | 0.2% |
| casual | 27 | 0.1% |

### 3.3 Interests (Train)

| Label | Count | % of Points |
|-------|------:|------------:|
| career_development | 1,472 | 7.9% |
| social | 764 | 4.1% |
| study_exam | 746 | 4.0% |
| pets | 744 | 4.0% |
| games | 704 | 3.8% |
| sports_fitness | 625 | 3.3% |
| art_design | 341 | 1.8% |
| reading_writing | 316 | 1.7% |
| travel_outdoor | 144 | 0.8% |
| music | 133 | 0.7% |
| film_animation | 108 | 0.6% |
| programming_technology | 82 | 0.4% |

### 3.4 Style (Train)

| Label | Count | % of Points |
|-------|------:|------------:|
| rational | 4,418 | 23.7% |
| direct | 2,603 | 14.0% |
| brief | 1,166 | 6.2% |
| detailed | 1,121 | 6.0% |
| high_emotional_expression | 945 | 5.1% |
| colloquial | 654 | 3.5% |
| indirect | 516 | 2.8% |
| formal | 128 | 0.7% |
| humorous | 81 | 0.4% |
| emoji_user | 27 | 0.1% |
| low_emotional_expression | 3 | 0.0% |

**Visual:** See `viz_profile_labels.png` for all three distributions.

---

## 4. Length Statistics

### 4.1 Characters

| Metric | Train History | Val History | Train Reply | Val Reply |
|--------|--------------:|------------:|------------:|----------:|
| Mean | 1,389 | 1,068 | 62 | 45 |
| Median (P50) | 813 | 740 | 129 | 98 |
| P90 | 3,020 | 2,313 | 517 | 336 |
| P99 | 9,693 | 5,212 | 1,353 | 847 |
| Max | 40,052 | 14,133 | 1,809 | 1,754 |

### 4.2 Approximate Tokens (÷3.5 chars/token)

| Metric | Train History | Val History | Train Reply | Val Reply |
|--------|--------------:|------------:|------------:|----------:|
| Median (P50) | ~229 | ~211 | ~37 | ~28 |
| P90 | ~863 | ~661 | ~148 | ~96 |
| P99 | ~2,769 | ~1,489 | ~387 | ~242 |
| Max | ~11,429 | ~4,026 | ~517 | ~501 |

### 4.3 Context Length Thresholds

| Threshold | Train > Thresh | Val > Thresh |
|-----------|---------------:|-------------:|
| 1,024 tokens | 7.5% | 3.1% |
| 2,048 tokens | 2.0% | 0.3% |
| 4,096 tokens | 0.3% | 0.0% |
| 8,192 tokens | 0.0% | 0.0% |

**Key Insight:** A 4K context window covers **99.7% of train** and **100% of val** histories. Even 2K covers 98%. The model's 32K context is massive overkill — truncation is rarely needed.

**Visual:** See `viz_length_distributions.png` for full histograms, and `viz_context_thresholds.png` (left panel) for threshold comparison.

---

## 5. Quick Reference

### 5.1 Emotions (16)

```
joy, gratitude, relaxed, care, pride, neutral, surprise,
mixed, sadness, loneliness, anxiety, anger, fear, disgust, shame, helplessness
```

### 5.2 Profile Labels (Data-Discovered, NOT from README)

> ⚠️ **These labels were extracted by scanning the gold data.** They differ from official documentation.

| Category | Count | Actual Labels in Data |
|----------|-------|----------------------|
| `personality_traits` | 10 | `sensitive`, `conservative`, `high_conscientiousness`, `assertive`, `agreeable`, `introverted`, `emotionally_stable`, `casual`, `open`, `extroverted` |
| `interests` | 12 | `career_development`, `pets`, `study_exam`, `sports_fitness`, `games`, `reading_writing`, `art_design`, `social`, `travel_outdoor`, `music`, `film_animation`, `programming_technology` |
| `style` | 11 | `rational`, `direct`, `detailed`, `brief`, `indirect`, `high_emotional_expression`, `colloquial`, `formal`, `humorous`, `emoji_user`, `low_emotional_expression` |

---

## 6. Recommendations for the Team

### For Ismail F. (Prompts & Submissions)
1. **Accuracy-first strategy:** Top-5 emotions = 70.8% of data. Optimize for these.
2. **Empty profile handling:** 37% of points have no profile. The model MUST learn to output empty JSON.
3. **Profile vocabulary:** Use the data-discovered labels in the system prompt, not the README labels.

### For Ismail M. (Training)
1. **Context window:** 4K is sufficient. 99.7% of histories fit. Don't waste compute on 32K.
2. **Class imbalance:** If using macro-F1, oversample rare emotions (joy, care, surprise, disgust, pride).
3. **Profile prediction:** Consider a separate classification head for profile labels — they're sparse and imbalanced.

### For Elly (Infrastructure)
1. **Truncation:** Needed for <0.3% of points. Drop oldest turns first, always keep target user turn.
2. **Latency:** Median reply is only ~28 tokens. Generation should be fast. Watch P99 (242 tokens).

### For Yahya (Evaluation)
1. **Baseline floors:** Always-anxiety = 32% accuracy. Random guess = 6.25% accuracy.
2. **Bootstrap CI:** With 2,354 points, a 1% accuracy improvement is ~23 points. Use bootstrap to distinguish real gains from noise.

---

*Report generated by `scripts/compute_stats.py`. Re-run when data changes.*
