# Zakaria's Dataset Deliverables

> **Competition:** 2026 M-Zone AI+ University Innovation Program  
> **Track:** Digital Human Comprehensive Emotional Companion Dialogue Model  
> **Role:** Dataset Owner  
> **Deadline:** Oct 20, 2026

---

## ⚠️ Critical Fix (Oct 4): Profile Vocabularies

**The documented profile vocabularies were WRONG.** Scanning the actual gold data revealed completely different labels:

| What docs/README said | What's actually in data |
|----------------------|------------------------|
| `conscientiousness` | `high_conscientiousness` |
| `agreeableness` | `agreeable` |
| `openness` | `open` |
| `extraversion` | `extroverted` |
| `gaming` | `games` |
| `sports` | `sports_fitness` |
| `reading` | `reading_writing` |
| `travel` | `travel_outdoor` |
| `art` | `art_design` |
| `technology` | `programming_technology` |
| `cooking`, `food`, `fashion` | **Not present** |

**Impact:** `build_sft.py` system prompt, `data-format.md`, and `data-stats.md` have been updated with the **correct** labels discovered from the data itself. `validate.py` must **warn, not reject**, on profile values until the official vocabulary is confirmed by organizers. See `docs/data-format.md` Section 5.2 for the full corrected list.

---

## What is in this package

| File | Task | Status | Who needs it |
|------|------|--------|--------------|
| `scripts/convert_val.py` | **B2** | Ready | Yahya (eval), Elly (inference) |
| `docs/data-format.md` | **B2** | Ready | Whole team |
| `scripts/compute_stats.py` | **B6** | Ready | Whole team |
| `docs/data-stats.md` | **B6** | Ready | Whole team |
| `train/build_sft.py` | **I1** | Ready | Ismail M. (training) |

---

## Quick start

```bash
# 1. Convert validation set → test input + gold labels
python scripts/convert_val.py \
    --in data/val_public.jsonl \
    --out data/val_input.jsonl \
    --gold data/val_gold.jsonl \
    --n 100          # optional: only first 100 points

# 2. Compute dataset statistics (re-run when data changes)
python scripts/compute_stats.py \
    --train data/train_public.jsonl \
    --val data/val_public.jsonl \
    --out docs/data-stats.md

# 3. Build SFT training data
python train/build_sft.py \
    --in data/train_public.jsonl \
    --out data/sft_pairs.jsonl \
    --llama-factory data/sft_llama_factory.json \
    --dev-ratio 0.05
```

---

## Task Reports

### B2: convert_val.py

**What it does:** Reads the official `val_public.jsonl` and produces two files:
- `val_input.jsonl` – test format that matches exactly what the evaluator sends
- `val_gold.jsonl` – answer key for scoring

**Key design choices:**
- History is truncated to end at `target_user_turn_id` (the last user message we see)
- Each point gets a unique ID: `{conversation_id}_t{target_user_turn_id}`
- Supports `--n N` for quick smoke tests

**How to improve:**
1. Add `--shuffle` flag to randomize point order for more robust validation
2. Add `--output-format` to support CSV or other formats if needed
3. Cache conversation metadata to avoid re-reading large files

---

### B6: compute_stats.py + data-stats.md

**What it does:** Analyzes train and val data, producing:
- Emotion distribution (both splits) — `viz_emotion_distribution.png`
- Profile label frequencies — `viz_profile_labels.png`
- Length percentiles (chars + approximate tokens) — `viz_length_distributions.png`
- Context-length threshold analysis — `viz_context_thresholds.png`
- Empty profile rate — `viz_context_thresholds.png` (pie chart)

**Key findings from real data (see `docs/data-stats.md` for full report):**

| Finding | Value | Action Needed |
|---------|-------|--------------|
| **Anxiety dominance** | 34.0% train / 31.9% val | Accuracy-first strategy: top-5 = 70.8% |
| **Rare emotions** | joy 0.9%, care 0.4%, surprise 0.3% | Oversample if macro-F1 is weighted |
| **Empty profiles** | 36.6% train / 37.2% val | Model must learn to output empty JSON |
| **History median** | 813 chars (~229 tokens) | 4K context covers 99.7% of points |
| **Reply median** | 129 chars (~37 tokens) | Generation is fast; watch P99 (~387 tok) |
| **Profile vocab bug** | README labels ≠ data labels | `validate.py` must warn, not reject |

**Visualizations generated:**
- `viz_emotion_distribution.png` — Side-by-side train/val emotion bars
- `viz_profile_labels.png` — Personality, interests, style distributions
- `viz_length_distributions.png` — History & reply length histograms with P50/P90/P99 lines
- `viz_context_thresholds.png` — Context limit comparison + empty profile pie chart

**How to improve:**
1. Install `transformers` for exact Qwen2.5 token counts (currently using 3.5 chars/token heuristic)
2. Add emotion co-occurrence analysis (anxiety → loneliness transitions?)
3. Add per-conversation emotion transition statistics
4. Add stratified sampling option to `convert_val.py` (ensure rare classes in eval subsets)

---

### I1: build_sft.py

**What it does:** Converts raw training data into SFT format for fine-tuning.

**Key design choices:**
- **Split by conversation_id**, never by prediction point (prevents leakage)
- **5% dev ratio** (~416 conversations in dev)
- **Truncation:** Drops oldest turns first when history exceeds token budget
- **Two output formats:**
  - `sft_pairs.jsonl` – simple `{prompt, completion}` pairs
  - `sft_llama_factory.json` – Alpaca format for LLaMA-Factory

**How to improve:**
1. **Rare-emotion oversampling:** Anxiety is 34% of data; joy/care/surprise are <1%. Oversample rare classes to improve macro-F1.
2. **Length bucketing:** Group examples by history length for more efficient batching during training.
3. **Profile-aware prompting:** Inject profile hints into the system prompt for points that have them.
4. **Multi-task format:** Consider separating emotion classification and response generation into distinct training objectives.

---

## Dependencies

```bash
pip install transformers  # optional, for exact token counts
```

No other dependencies required – scripts use only Python standard library + json.

---

## Notes for teammates

- **Yahya:** `val_input.jsonl` + `val_gold.jsonl` are ready for your eval pipeline.
- **Elly:** The test format in `val_input.jsonl` matches exactly what `start.sh` receives.
- **Ismail M.:** `sft_llama_factory.json` is ready for LLaMA-Factory. Let me know if you need a different format.
- **Ismail F.:** Stats show anxiety is 34% – consider class-weighted loss or oversampling.
